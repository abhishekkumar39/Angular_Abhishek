import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, RouterOutlet } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { StudentListComponent } from './components/student-list/student-list.component';
import { StudentFormComponent } from './components/student-form/student-form.component';
import { TeacherListComponent } from './components/teacher-list/teacher-list.component';
import { TeacherFormComponent } from './components/teacher-form/teacher-form.component';
import { CourseListComponent } from './components/course-list/course-list.component';
import { CourseFormComponent } from './components/course-form/course-form.component';
import { SessionListComponent } from './components/session-list/session-list.component';
import { SessionFormComponent } from './components/session-form/session-form.component';
import { FormsModule } from '@angular/forms';
import { StudentService } from './services/student.service';
import { TeacherService } from './services/teacher.service';
import { CourseService } from './services/course.service';
import { SessionService } from './services/session.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    StudentListComponent,
    StudentFormComponent,
    TeacherListComponent,
    TeacherFormComponent,
    CourseListComponent,
    CourseFormComponent,
    SessionListComponent,
    SessionFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule,
    RouterOutlet
  ],
  providers: [StudentService, TeacherService, CourseService, SessionService],
  bootstrap: [AppComponent]
})
export class AppModule { }


