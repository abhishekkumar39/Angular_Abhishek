import { Component, OnInit } from '@angular/core';
import { SessionService } from 'src/app/services/session.service';
import { SessionModel } from 'src/app/models/session.model';
@Component({
  selector: 'app-session-list',
  templateUrl: './session-list.component.html',
  styleUrls: ['./session-list.component.css']
})
export class SessionListComponent implements OnInit{
  sessions: any[]=[];
  constructor(private sessionService:SessionService) {}
  ngOnInit(): void {
  this.sessions = this.sessionService.getSessions();
  }
}
 {

}
