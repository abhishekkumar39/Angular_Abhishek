import { Component } from '@angular/core';
import { StudentService } from 'src/app/services/student.service';
import { FormGroup, FormBuilder, Validators } from'@angular/forms';
@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent {

    studentForm : FormGroup | undefined;
    constructor(private fb: FormBuilder, private studentService: StudentService) { this.studentForm = this.fb.group({
      student_id: ['', Validators.required],
      student_name: ['', [Validators.required]],
      course_name: ['', Validators.required],
      phone_number: ['', [Validators.required]]
          });
      }
      onSubmit() {
      if (this.studentForm?.valid) {
        this.studentService.addStudents( this.studentForm.value as any);
      }
      }
   
  }
  