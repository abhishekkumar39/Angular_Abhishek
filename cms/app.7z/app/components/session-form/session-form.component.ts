import { Component } from '@angular/core';
import { SessionService } from 'src/app/services/session.service';
import { FormGroup, FormBuilder, Validators } from'@angular/forms';
 
@Component({
  selector: 'app-session-form',
  templateUrl: './session-form.component.html',
  styleUrls: ['./session-form.component.css']
})
export class SessionFormComponent {
  sessionForm : FormGroup | undefined;
  constructor(private fb: FormBuilder, private sessionService: SessionService) { this.sessionForm = this.fb.group({
    year: ['', Validators.required],
    session_id: ['', [Validators.required]],
    course_id: ['', [Validators.required]],
    teacher_id: ['', [Validators.required]]
        });
    }
    onSubmit() {
    if (this.sessionForm?.valid) {
      this.sessionService.addSessions( this.sessionForm.value as any)
    }
    }
 
}

