import { Component } from '@angular/core';
import { CourseService } from 'src/app/services/course.service';
import { FormGroup, FormBuilder, Validators } from'@angular/forms';
 
@Component({
  selector: 'app-course-form',
  templateUrl: './course-form.component.html',
  styleUrls: ['./course-form.component.css']
})
export class CourseFormComponent {
  courseForm : FormGroup | undefined;
  constructor(private fb: FormBuilder, private courseService: CourseService) { this.courseForm = this.fb.group({
    course_id: ['', Validators.required],
    course_name: ['', [Validators.required]]
        });
    }
    onSubmit() {
    if (this.courseForm?.valid) {
      this.courseService.addCourses( this.courseForm.value as any)
    }
    }
 
}