import { Component } from '@angular/core';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginFailed = false;
  constructor(private route: Router) {}
    onLogin(form: any) {
      const success = form.valid;
      if (!success) {
      this.loginFailed = true;
      } else {
      this.loginFailed = false;
      form.reset();
      this.route.navigate(['/home']);
      }
      }
    }