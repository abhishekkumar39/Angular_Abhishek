import { Component,OnInit  } from '@angular/core';
import { TeacherService } from 'src/app/services/teacher.service';
import { TeacherModel } from 'src/app/models/teacher.model';
@Component({
  selector: 'app-teacher-list',
  templateUrl: './teacher-list.component.html',
  styleUrls: ['./teacher-list.component.css']
})
export class TeacherListComponent implements OnInit {
  teachers: any[]=[];
  constructor(private teacherService:TeacherService) {}
  ngOnInit(): void {
  this.teachers = this.teacherService.getTeachers();
  }
}



