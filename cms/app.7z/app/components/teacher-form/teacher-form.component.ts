import { Component } from '@angular/core';
import { TeacherService } from 'src/app/services/teacher.service';
import { FormGroup, FormBuilder, Validators } from'@angular/forms';
@Component({
  selector: 'app-teacher-form',
  templateUrl: './teacher-form.component.html',
  styleUrls: ['./teacher-form.component.css']
})
export class TeacherFormComponent {
  teacherForm : FormGroup | undefined;
  constructor(private fb: FormBuilder, private teacherService: TeacherService) { this.teacherForm = this.fb.group({
    teacher_id: ['', Validators.required],
    teacher_name: ['', [Validators.required]],
    salary: ['', Validators.required]
    
        });
    }
    onSubmit() {
    if (this.teacherForm?.valid) {
      this.teacherService.addTeachers( this.teacherForm.value as any)
    }
    }
 
}