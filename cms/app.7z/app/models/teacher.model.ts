export interface TeacherModel {
    teacher_id: number;
    teacher_name:string;
    salary: number;


}
