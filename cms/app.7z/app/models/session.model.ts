export interface SessionModel {
          year: number;
          session_id:number;
          course_id:number;
          teacher_id:number;
          
}
