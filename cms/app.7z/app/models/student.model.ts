export interface StudentModel {
    student_id: number;
    student_name:string;
    course_name: string;
    phone_number:number;
}

