export interface CourseModel {
    
        course_id: number;
        course_name: string;

        }

