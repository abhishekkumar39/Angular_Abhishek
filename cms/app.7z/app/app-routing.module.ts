import { NgModule } from '@angular/core';
import { RouterModule, Routes, RouterOutlet } from '@angular/router';
import { HomeComponent } from'./components/home/home.component';
import { LoginComponent } from'./components/login/login.component';
import { StudentListComponent } from './components/student-list/student-list.component';
import { StudentFormComponent } from './components/student-form/student-form.component';
import { TeacherListComponent } from './components/teacher-list/teacher-list.component';
import { TeacherFormComponent } from './components/teacher-form/teacher-form.component';
import { CourseListComponent } from './components/course-list/course-list.component';
import { CourseFormComponent } from './components/course-form/course-form.component';
import { SessionListComponent } from './components/session-list/session-list.component';
import { SessionFormComponent } from './components/session-form/session-form.component';
 
const routes: Routes = [
{ path: '', component: LoginComponent },
{ path: 'home', component: HomeComponent },
{ path: 'students', component: StudentListComponent },
{ path: 'student', component: StudentFormComponent },
{ path: 'teachers', component: TeacherListComponent },
{ path: 'teacher', component: TeacherFormComponent },
{ path: 'courses', component: CourseListComponent },
{ path: 'course', component: CourseFormComponent },
{ path: 'sessions', component: SessionListComponent },
{ path: 'session', component: SessionFormComponent }
];
 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule,RouterOutlet]
})
export class AppRoutingModule { }
 