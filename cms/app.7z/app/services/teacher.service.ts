import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TeacherService {
  teachers:any[]=[];
  constructor() { }
  getTeachers():any[]
  {
    return this.teachers;
  }
  addTeachers(teacher:any) {

    this.teachers.push(teacher); }
}