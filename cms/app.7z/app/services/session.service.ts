import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SessionService {
  sessions:any[]=[];
  constructor() { }
  getSessions():any[]
  {
    return this.sessions;
  }
  addSessions(session:any) {

    this.sessions.push(session); 
  }
}
