import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
courses:any[]=[];
  constructor() { }
  getCourses():any[]
  {
    return this.courses;
  }
  addCourses(courses:any) {

    this.courses.push(courses);
  }

}
