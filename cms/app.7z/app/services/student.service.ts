import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  students:any[]=[];
  constructor() { }
  getStudents():any[]
  {
    return this.students;
  }
  addStudents(student:any) {

    this.students.push(student); }
}

